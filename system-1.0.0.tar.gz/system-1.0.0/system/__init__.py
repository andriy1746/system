# __init__.py
import importlib.metadata

def version():
	importlib.metadata.version("system")

def print_updatable(**text, sep=" ", file=None):
	print(**text, end="\r", sep=sep, file=file)